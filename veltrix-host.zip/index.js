const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname)));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/panel', (req, res) => {
    res.sendFile(path.join(__dirname, 'panel.html'));
});

io.on('connection', (socket) => {
    console.log('مستخدم متصل باللوحة.');

    socket.on('server_action', (action) => {
        if (action === 'start') {
            socket.emit('console_log', '[Veltrix Host] جاري تشغيل السيرفر...');
            setTimeout(() => socket.emit('console_log', '[Veltrix Host] البوت يعمل الآن بكفاءة 24/7 ✅'), 1000);
        } else if (action === 'stop') {
            socket.emit('console_log', '[Veltrix Host] تم إيقاف السيرفر.');
        } else if (action === 'restart') {
            socket.emit('console_log', '[Veltrix Host] جاري إعادة التشغيل...');
            setTimeout(() => socket.emit('console_log', '[Veltrix Host] تم إعادة تشغيل السيرفر بنجاح.'), 1000);
        }
    });
});

server.listen(PORT, () => {
    console.log(`Veltrix Host is running on port ${PORT}`);
});
